LOCK IN v0.9  (gym only)

NO BACKEND. No account, no keys. Everything is saved on the device.
Back up from You > Export backup, restore with Import backup. Old v0.4 backups still import.

NEW IN v0.9
- Make your workout plan now opens with "How many days will you work out?" Tap 1-7 and build each day with its own title,
  photo (or emoji icon), exercises, sets, reps and rest. Add a cover photo for the whole plan
- You > Default weights: set your usual barbell, dumbbell, kettlebell and machine/cable weight (+/- or type). It saves
  automatically and new exercises start at that weight. Your past lifts and weights you enter still take priority

IN v0.8 (FINAL ADDITIONS)
- Harder generated plans: more exercises and sets per session (old plans upgrade automatically, your next-up day is kept)
- After each generated-plan workout it asks "How was the training load?" (Too light / Well calibrated / Too demanding).
  Too demanding = one fewer set per exercise, more rest, last exercise dropped. Too light = one more set, less rest,
  and one extra exercise. Well calibrated leaves it unchanged
- 856 exercises (adds Mobility and warm-ups, Olympic lifts, strongman, calisthenics skills, machines, plyometrics, cardio)
- 60 equipment types in setup (every machine, bar, band, ring, trainer, cardio machine and gym tool); generated plans use them

NEW IN v0.8
- Asks how much you lift: after building your plan, and whenever you start a workout or add an exercise you haven't
  logged yet, it asks for your working weight (blank = bodyweight). Update them any time in You > Update my weights
- Make your own plan: Train > "Make your workout plan". Pick 1-7 days, give every day a title and photo, add
  exercises with your own sets, reps and rest, reorder them, and put a photo on any exercise. The generated plan stays ready to go
- 429 exercises in the library (chest, back, legs, shoulders, arms, core, cardio, full body), searchable, plus custom ones
- Auto step counting using the phone's motion sensor (On by default, toggle in Today > Steps). iPhone asks for motion
  permission on your first tap. It counts only while the app is open; for all-day totals keep the Apple Health Shortcut

IN v0.7
- New logo (padlock + dumbbell) and a cleaner UI: ring tiles for daily targets, floating nav, equipment tiles
- Smarter plans: every exercise has a movement group and a session never repeats one (no two curls,
  no two vertical pulls). Best-quality lifts first, beginners get easier variations, A/B days rotate
- Sets, reps and rest time are set per exercise from your goal and experience; the rest timer uses them

IN v0.6
- Equipment step in setup: pick exactly what you own (barbell, rack, benches, dumbbells, kettlebells,
  pull-up bar, dip bars, bands, cable/lat/leg/chest machines, ab wheel). Plans only use what you have
- Casual daily quests (log a meal, 4 glasses of water, 5,000 steps, 10 sets...), no more PR quest
- Apple Health steps via a one-time Shortcut (Today > Steps > Auto-sync from Apple Health)

IN v0.5
- Gym-only: habits, focus tasks and sleep removed
- Daily targets built from your plan (goal, weight, sex, age, days/week):
  calorie MAX, protein goal, water goal, step goal
- Today screen: log food (kcal + protein), tap +Glass for water (250 ml), log steps
- Water pace nudge: tells you when you're behind for the time of day
- Each target hit = +10 XP, all 4 in a day = Perfect Day (+30). Calories only count
  when you eat 60-100% of your max, so under-eating isn't rewarded
- Quests and achievements rewritten around training and targets

HOSTING
Upload ALL files (index.html, sw.js, manifest.json, 3 icons) to Netlify/Vercel/GitHub Pages.
Open the https link in Safari > Share > Add to Home Screen.
If you see an old version, delete the home screen app and re-add it.
Bump VERSION in sw.js whenever you update.

NOTE
Data lives in the browser. Clearing Safari data or deleting the app erases it, so export backups.
Auto step counting only works while the app is open (a web app can't run in the background or read Apple Health directly). Estimates are not medical advice.
